## Tools
- 3D printer (PETG capable)
- M3 hex key
- Soldering iron with fine tip and solder
- Wire strippers
- Flush cutters
- Multimeter
- Heat gun (for heat set inserts)
- Small Phillips head screwdriver
- Tweezers or small pliers

## Assumptions
- Basic 3D printing knowledge (slicing, material settings)
- Basic soldering experience for small components
- Familiarity with microcontroller programming (e.g., Arduino IDE) and uploading firmware
- Computer with USB port and internet access for firmware and libraries

## 1. Fabrication
### 1.1 3D print all mechanical components according to specified material and print settings
*(not yet generated)*

### 1.2 Install M3 Heat Set Inserts into all designated mounting points on 3D printed parts
*(not yet generated)*

### 1.3 Assemble the tank track sections using track connecting pins
*(not yet generated)*

## 2. Wiring
### 2.1 Solder main power wires from LiPo Battery to Charging Module (IN+/IN-)
*(not yet generated)*

### 2.2 Solder power wires from Charging Module (OUT+/OUT-) to Boost Converter (IN+/IN-)
*(not yet generated)*

### 2.3 Solder power wires from Boost Converter (OUT+/OUT-) to Main MCU (VIN/GND), Display Screen (VCC/GND), and Front Obstacle Sensor (VCC/GND)
*(not yet generated)*

### 2.4 Solder power wires from Charging Module (BAT+/BAT-) to Motor Driver (VCC/GND)
*(not yet generated)*

### 2.5 Connect Main MCU to Display Screen via I2C (GPIO to SCL, GPIO to SDA)
*(not yet generated)*

### 2.6 Connect Main MCU to Motor Driver control pins (GPIO to IN1, IN2, IN3, IN4, ENA, ENB)
*(not yet generated)*

### 2.7 Connect Main MCU to Front Obstacle Sensor (GPIO to Trig, GPIO to Echo)
*(not yet generated)*

### 2.8 Connect Motor Driver outputs (OUT1/OUT2) to Left Track Drive Motor and (OUT3/OUT4) to Right Track Drive Motor
*(not yet generated)*

## 3. Bring-up
### 3.1 Upload initial firmware to Main Controller (MCU) via USB
*(not yet generated)*

### 3.2 Verify power rails (3.7V and 5V) using a multimeter at various module VCC/GND pins
*(not yet generated)*

### 3.3 Test I2C communication and display text on Information Display Screen via MCU
*(not yet generated)*

### 3.4 Test Motor Driver functionality and spin Left and Right Track Drive Motors independently
*(not yet generated)*

### 3.5 Test Front Obstacle Sensor by reading distance values on MCU serial monitor
*(not yet generated)*

## 4. Assembly
### 4.1 Mount all 3D printed mounts to the Main Chassis Base Plate using M3 screws
*(not yet generated)*

### 4.2 Secure all electrical components into their respective 3D printed mounts
*(not yet generated)*

### 4.3 Mount the Information Display Screen into its Bezel and attach to the Front Enclosure Panel
*(not yet generated)*

### 4.4 Install the Front Obstacle Sensor into its mount and attach to the Front Enclosure Panel
*(not yet generated)*

### 4.5 Attach Left/Right Drive Sprockets to motors and install Idler Wheels with shafts into the chassis
*(not yet generated)*

### 4.6 Route and secure all wired connections, ensuring proper length and strain relief
*(not yet generated)*

### 4.7 Fit the assembled Tank Track Sections onto the drive sprockets and idler wheels
*(not yet generated)*

### 4.8 Fasten the Front Enclosure Panel to the Main Chassis and then attach the Top Enclosure Cover using standoffs and M3 screws
*(not yet generated)*
